package dev.mvc.member;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("dev.mvc.member.MemberDAO")
public class MemberDAO implements MemberDAOInter {
  @Autowired
  private SqlSessionTemplate mybatis; // MyBATIS 3 ���� ��ü

  public MemberDAO(){
    System.out.println("--> MemberDAO created.");  
  }
  
  @Override
  public int checkId(String id) {
    /*
     <mapper namespace = "member">
       <select id='checkId' resultType='int' parameterType='String'> 
     */
    return mybatis.selectOne("member.checkId", id);
  }

  @Override
  public int create(MemberVO vo) {
    //   <insert id="create" parameterType="MemberVO">
    return mybatis.insert("member.create", vo);
  }

  @Override
  public List<MemberVO> list() {
    return mybatis.selectList("member.list");
  }

  @Override
  public MemberVO read(int mno) {
    return mybatis.selectOne("member.read", mno);
  }

  @Override
  public int update(MemberVO memberVO) {
    return mybatis.update("member.update", memberVO);
  }

  @Override
  public int passwdCheck(int mno, String passwd) {
    Map map = new HashMap();
    map.put("mno", mno);
    map.put("passwd", passwd);
    return mybatis.selectOne("member.passwdCheck", map);
  }

  @Override
  public int update_passwd(int mno, String passwd) {
    Map map = new HashMap();
    map.put("mno", mno);
    map.put("passwd", passwd);
    return mybatis.update("member.update_passwd", map);
  }
  
  @Override
  public int delete(int mno) {
    return mybatis.delete("member.delete", mno);
  }
  
  @Override
  public int login(MemberVO memberVO) {
    return mybatis.selectOne("member.login", memberVO);
  }
  
}



