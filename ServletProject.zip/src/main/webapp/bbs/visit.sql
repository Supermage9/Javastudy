select * from VISIT;
select * from tab;

create table Test (
no number not null,
name varchar2(20) not null
);
