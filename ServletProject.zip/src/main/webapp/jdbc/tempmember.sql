select * from tab;

create table tempmember (

  id  varchar2(20) not null,
  passwd varchar2(20),
  name varchar2(20),
  mem_num1  varchar2(6),
  mem_num2  varchar2(7),
  e_mail varchar2(50),
  phone  varchar2(30),
  zipcode varchar2(7),
  address varchar2(80),
  job varchar2(30),
  primary key (id)

);

select * from tempmember;

insert into tempmember values('aaaa', '1111', '홍길동', '123456','7654321','hong@naver.com', '010-1234-1234','100-100', '서울탁별시 영등포구 영종로 56 신한빌딩 4층','프로그래머');
insert into tempmember values('bbbb', '2222', '손오공', '654321','7654321','son@naver.com', '010-1234-4321','200-200', '부산 광역시 동래구 해운대로 해운빌딩 4층','격투가');
insert into tempmember values('cccc', '3333', '강감찬', '654321','1234567','kang@naver.com', '010-4321-1234','300-300', '함경북도 개성시 개성읍 영종로 56 개성빌딩 4층','고려장군');





