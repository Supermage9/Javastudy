package dev.mvc.blog;
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import web.tool.Paging;
import web.tool.SearchDTO;
import web.tool.Tool;
import web.tool.Upload;
 
@Controller
public class BlogCont {
  @Autowired
  @Qualifier("dev.mvc.blog.BlogDAO")
  private BlogDAOInter blogDAO;

  public BlogCont(){
    System.out.println("--> BlogCont created.");
  }
  
  @RequestMapping(value = "/blog/create.do", 
                              method = RequestMethod.GET)
  public ModelAndView create() {
    // System.out.println("--> create() GET called.");
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/blog/create"); // /webapp/blog/create.jsp

    return mav;
  }

  /**
   * ��� ó��
   * @param blogVO
   * @param request
   * @param session
   * @return
   */
  @RequestMapping(value = "/blog/create.do", 
                             method = RequestMethod.POST)
  public ModelAndView create(BlogVO blogVO, 
                                           HttpServletRequest request, 
                                           HttpSession session) {
    // System.out.println("--> create() POST called.");
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/blog/message");

    ArrayList<String> msgs = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>();

    // -------------------------------------------------------------------
    // ���� ����
    // -------------------------------------------------------------------
    String thumb = "";
    String file1 = "";
    long size1=0;
    String upDir = Tool.getRealPath(request, "/blog/storage");
    MultipartFile file1MF = blogVO.getFile1MF();
    size1 = file1MF.getSize();

    if (size1 > 0) {
      file1 = Upload.saveFileSpring(file1MF, upDir);
      // -------------------------------------------------------------------
      // Thumb ���� ����
      // -------------------------------------------------------------------
      if (Tool.isImage(file1)) {
        thumb = Tool.preview(upDir, file1, 120, 80);
      } else {
        thumb = "";
      }
      // -------------------------------------------------------------------
    }
    blogVO.setThumb(thumb); // Thumb �̹���
    blogVO.setFile1(file1);       // ���� �̹���
    blogVO.setSize1(size1);     // ���� �̹��� ũ��
    // -------------------------------------------------------------------
    
    if (blogDAO.create(blogVO) == 1) {
      msgs.add("���� ����߽��ϴ�.");
      links.add("<button type='button' onclick=\"location.href='./create.do'\">��� ���</button>");
    } else {
      msgs.add("�� ��Ͽ� �����߽��ϴ�.");
      msgs.add("�ٽ� �õ����ּ���.");
      links.add("<button type='button' onclick=\"history.back()\">�ٽýõ�</button>");
    }

    links.add("<button type='button' onclick=\"location.href='./home.do'\">Ȩ������</button>");
    links.add("<button type='button' onclick=\"location.href='./list.do'\">���</button>");
    mav.addObject("msgs", msgs);
    mav.addObject("links", links);

    return mav;
  }

  /**
   * ���� ��ȸ�մϴ�
   * @param blogno
   * @return
   */
  @RequestMapping(value = "/blog/read.do", 
                             method = RequestMethod.GET)
  public ModelAndView read(int blogno, SearchDTO searchDTO) {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/blog/read");
    BlogVO blogVO = blogDAO.read(blogno);
    
    // String content = blogVO.getContent();
    // content = Tool.convertChar(content); // Ư�� ���� ó��
    // blogVO.setContent(content);
    long size1 = blogVO.getSize1();
    blogVO.setSize1Label(Tool.unit(size1));
    
    mav.addObject("blogVO", blogVO); 
    
    return mav;
  }
  
  /**
   * ������
   * @param blogno
   * @return
   */
  @RequestMapping(value="/blog/update.do", 
                             method=RequestMethod.GET)
  public ModelAndView update(int blogno){  
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/blog/update");
    BlogVO blogVO = blogDAO.read(blogno);
    mav.addObject("blogVO", blogVO);
    
    return mav;

  }
   
  /**
   * �۰� ������ ���� ó��
   * @param blogVO
   * @return
   */
  @RequestMapping(value = "/blog/update.do", 
                             method = RequestMethod.POST)
  public ModelAndView update(BlogVO blogVO, HttpServletRequest request) {
    ModelAndView mav = new ModelAndView();

    ArrayList<String> msgs = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>();

    // -------------------------------------------------------------------
    // ���� ���� ����
    // -------------------------------------------------------------------
    String thumb = "";
    String file1 = "";
    long size1=0;
    String upDir = Tool.getRealPath(request, "/blog/storage");
    MultipartFile file1MF = blogVO.getFile1MF();
    size1 = file1MF.getSize();
    BlogVO oldVO = blogDAO.read(blogVO.getBlogno());
    
    if (size1 > 0) {
      Tool.deleteFile(upDir, oldVO.getFile1()); // ���� ��ϵ� ���� ����
      file1 = Upload.saveFileSpring(file1MF, upDir); // ���ο� ���� ����

      // -------------------------------------------------------------------
      // Thumb ���� ����
      // -------------------------------------------------------------------
      if (Tool.isImage(file1)) { // �̹������� �˻�
        Tool.deleteFile(upDir, oldVO.getFile1()); // ���� ����
        thumb = Tool.preview(upDir, file1, 120, 80); // thumb �̹��� ����
      } else {
        thumb = "";
      }
      // -------------------------------------------------------------------

    } else {
      thumb = oldVO.getThumb(); // ���� ���ε带���� �ʴ� ���
      file1 = oldVO.getFile1();
      size1 = oldVO.getSize1();
    }
    blogVO.setThumb(thumb); 
    blogVO.setFile1(file1);
    blogVO.setSize1(size1);
    // -------------------------------------------------------------------

    if (blogDAO.update(blogVO) == 1) {
      // ������ ��ȸ�� �ڵ� �̵�
      mav.setViewName("redirect:/blog/read.do?blogno=" + blogVO.getBlogno()); // Ȯ���� ����
    } else {
      msgs.add("�Խ��� ������ ���� �ϼ̽��ϴ�.");
      links.add("<button type='button' onclick=\"history.back()\">�ٽ� �õ�</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do'\">���</button>");
      mav.addObject("msgs", msgs);
      mav.addObject("links", links);
    }

    return mav;
  }

  /**
   * ������
   * @param blogno
   * @return
   */
  @RequestMapping(value = "/blog/delete.do", 
                              method = RequestMethod.GET)
  public ModelAndView delete(int blogno) {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/blog/delete"); // /webapp/blog/delete.jsp
    mav.addObject("blogno", blogno);

    return mav;
  }
  
  /**
   * ���� ó��
   * @param blogVO
   * @return
   */
  @RequestMapping(value = "/blog/delete.do", 
                             method = RequestMethod.POST)
  public ModelAndView delete(BlogVO blogVO) {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/blog/message");

    ArrayList<String> msgs = new ArrayList<String>();
    ArrayList<String> links = new ArrayList<String>();
    
    if (blogDAO.delete(blogVO.getBlogno()) == 1) {
      mav.setViewName("redirect:/blog/list.do");//Ȯ���� ����

    } else {
      msgs.add("�� ������ �����߽��ϴ�.");
      links.add("<button type='button' onclick=\"history.back()\">�ٽýõ�</button>");
      links.add("<button type='button' onclick=\"location.href='./home.do'\">Ȩ������</button>");
      links.add("<button type='button' onclick=\"location.href='./list.do'\">���</button>");
    }
    
    mav.addObject("msgs", msgs);
    mav.addObject("links", links);
    
    return mav;
  }
  
  /**
   * �Խ��� ����� �˻�+����¡�Ͽ� ����մϴ�.
   * 
   * @param searchDTO �˻� ����         
   * @return ����� �Խ��� ���
   */
  @RequestMapping(value = "/blog/list.do", 
                             method = RequestMethod.GET)
  public ModelAndView list(SearchDTO searchDTO,
                                    HttpServletRequest request) {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("/blog/list");
    int totalRecord = 0;

    // HashMap hashMap = new HashMap();
    HashMap<String, Object> hashMap = new HashMap<String, Object>();
    hashMap.put("col", searchDTO.getCol());
    hashMap.put("word", searchDTO.getWord());
    
    int recordPerPage = 10; // �������� ����� ���ڵ� ����
    // ���������� ����� ���� ���ڵ� ��ȣ ���, nowPage�� 1���� ����
    int beginOfPage = (searchDTO.getNowPage() - 1) * 10; 
    // 1 page: 0
    // 2 page: 10
    // 3 page: 20
    int startNum = beginOfPage + 1; // ���� rownum, 1
    int endNum = beginOfPage + recordPerPage; // ���� rownum, 10
    hashMap.put("startNum", startNum);
    hashMap.put("endNum", endNum);

    List<BlogVO> list = blogDAO.list(hashMap); // �˻�
    Iterator<BlogVO> iter = list.iterator();
    while (iter.hasNext() == true) { // ���� ��� �˻�
      BlogVO vo = iter.next(); // ��� ����
      vo.setTitle(Tool.textLength(vo.getTitle(), 10));
      vo.setRdate(vo.getRdate().substring(0, 10));
      // vo.setFile1(Tool.textLength(10, vo.getFile1()));
      // vo.setFile2(Tool.textLength(10, vo.getFile2()));
      vo.setSize1Label(Tool.unit(vo.getSize1()));
    }
    mav.addObject("list", list);

    mav.addObject("root", request.getContextPath());
    
    totalRecord = blogDAO.count(hashMap);
    mav.addObject("totalRecord", blogDAO.count(hashMap)); // �˻��� ���ڵ� ����

    String paging = new Paging().paging4("/list.do",
                                           totalRecord, 
                                           searchDTO.getNowPage(), 
                                           recordPerPage, 
                                           searchDTO.getCol(), 
                                           searchDTO.getWord());
    mav.addObject("paging", paging);
    return mav;
  }

 
}


