package dev.mvc.blog;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("dev.mvc.blog.BlogDAO")
public class BlogDAO implements BlogDAOInter{
  @Autowired
  private SqlSessionTemplate mybatis; // MyBATIS 3 ���� ��ü

  public BlogDAO(){
    System.out.println("--> BlogDAO created.");  
  }

  @Override
  public int create(BlogVO blogVO) {
    return mybatis.insert("blog.create", blogVO);
  }

  @Override
  public List<BlogVO> list(HashMap hashmap) {
    return mybatis.selectList("blog.list", hashmap);
  }
  
  @Override
  public BlogVO read(int blogno) {
    return mybatis.selectOne("blog.read", blogno);
  }

  @Override
  public int update(BlogVO vo) {
    return mybatis.update("blog.update", vo);
  }

  @Override
  public int delete(int blogno) {
    return mybatis.delete("blog.delete", blogno);
  }

  @Override
  public int count(HashMap hashmap) {
    return mybatis.selectOne("blog.count", hashmap);
  }

  
}







